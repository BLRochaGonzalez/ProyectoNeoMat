package org.iesalixar.bluisrochag.neomat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NeoMatApplication {

	public static void main(String[] args) {
		SpringApplication.run(NeoMatApplication.class, args);
	}

}
