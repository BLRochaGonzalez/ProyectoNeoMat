package org.iesalixar.bluisrochag.neomat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NeoMatApplicationTests {

	@Test
	void contextLoads() {
	}

}
