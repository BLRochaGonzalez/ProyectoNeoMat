## URL Wireframe

* https://80mg73.axshare.com

## URL Mock-Up

* https://1cdsmb.axshare.com
- para que el aplicativo te deje hacer login, deberás registrarte previamente con tus datos, el sistema comprobará que los datos de login sean los mismos que los de registro, al igual que comprobará en el paso de registro que la contraseña sea la misma que la repetición